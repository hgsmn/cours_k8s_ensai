import logging
import os
import shutil
from pathlib import Path

from fastapi import FastAPI, UploadFile

UPLOAD_DIR = Path(os.getenv("UPLOAD_DIR", "/data/uploads"))
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
logger = logging.getLogger("upload-api")

app = FastAPI(title="Upload API")


@app.get("/health")
def health():
    return {"status": "ok"}


@app.post("/upload", status_code=201)
def upload(file: UploadFile):
    destination = UPLOAD_DIR / Path(file.filename).name
    with destination.open("wb") as out:
        shutil.copyfileobj(file.file, out)
    size = destination.stat().st_size
    logger.info("Fichier %s enregistré (%d octets)", destination.name, size)
    return {"filename": destination.name, "size": size}


@app.get("/files")
def list_files():
    return [
        {"filename": f.name, "size": f.stat().st_size}
        for f in sorted(UPLOAD_DIR.iterdir())
        if f.is_file()
    ]
